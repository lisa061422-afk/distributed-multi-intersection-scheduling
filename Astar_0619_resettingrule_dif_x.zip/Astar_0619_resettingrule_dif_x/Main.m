% Single-intersection centralized A* scheduler
tic; clear all;

% ===================== Algorithm switches ====================================
cfg.useWeakRule  = true;   % 初始值无影响 — 下方循环自动跑 ON 和 OFF 两遍
cfg.pruneNodes   = false;  % false → all branches survive (multiple leaves visible)
cfg.useBnB       = false;  % false → keep all valid paths
cfg.useTBound    = true;   % prune nodes with tw > serial worst-case deadline (OFF only)
cfg.timeout_s    = 30;     % max run time per pass (s); 0 = no limit

% ===================== Physical parameters ===================================
cfg.v_max        = 20;     % vehicle speed (m/s)
cfg.detect_range = 510;    % detection zone diameter (m)
cfg.W            = 30;     % merging zone width (m)

% ===================== Systems and route assignment ==========================
% Route numbering:  Arm1: 1=left 2=straight 3=right
%                   Arm2: 4=left 5=straight 6=right
%                   Arm3: 7=left 8=straight 9=right
%                   Arm4: 10=left 11=straight 12=right
cfg.routeAssignment = [1 4 5];
% cfg.routeAssignment = [10 3 1 4];   % Trial13 debug: ON=1.5743 OFF=1.7302

% Initial arrival offset d1(n): U[0,3] random or manual (length = N)
cfg.d1 = [0, 0, 0];
% cfg.d1 = [0.48, 2.79, 2.42, 1.90];  % Trial13 debug

% ===================== Intersection config ===================================
intCfg   = makeIntersectionConfig();
cfg.N    = numel(cfg.routeAssignment);
cfg.M    = intCfg.M;
cfg.S    = intCfg.S;
cfg.Map  = intCfg.Map(:, cfg.routeAssignment);
cfg.C    = intCfg.C(:,   cfg.routeAssignment);
cfg.T_period = 20;
cfg.T        = repmat({{cfg.T_period}}, cfg.N, 1);
cfg.Ni       = ones(1, cfg.N);
cfg          = buildCfgInitials(cfg);

% ===================== Run BOTH WeakRule=ON and OFF ==========================
results_both = struct([]);
for useWeak = [true, false]
    cfg.useWeakRule = useWeak;
    ruleStr = 'ON'; if ~useWeak, ruleStr = 'OFF'; end
    fprintf('\n--- WeakRule %s ---\n', ruleStr);

    [NODES, LEAF, c_node_index, timed_out, elapsedTime] = runAstar(cfg);

    fprintf('Total nodes : %d\n', size(NODES,1));
    fprintf('Elapsed time: %.4f s\n', elapsedTime);

    if c_node_index > 0
        resultNodes = [];
        idx = c_node_index;
        while idx > 0, resultNodes = [idx, resultNodes]; idx = NODES{idx}{7}; end
        fprintf('Optimal g-cost: %.4f\n', NODES{resultNodes(end)}{10});
        log_cost = NODES{c_node_index}{10};
    else
        fprintf('(No complete path)\n');
        log_cost = NaN;
    end

    logResultCSV(cfg, log_cost, numel(LEAF), size(NODES,1), elapsedTime, timed_out);

    ri = numel(results_both) + 1;
    results_both(ri).NODES      = NODES;
    results_both(ri).LEAF       = LEAF;
    results_both(ri).c_node_idx = c_node_index;
    results_both(ri).timed_out  = timed_out;
    results_both(ri).elapsed    = elapsedTime;
    results_both(ri).useWeak    = useWeak;
end

r_on  = results_both(1);   % WeakRule ON
r_off = results_both(2);   % WeakRule OFF
cfg.useWeakRule = true;
save('nodes.mat', 'NODES');

% ===================== HTML interactive demo =================================
if ~isempty(r_on.LEAF) || ~isempty(r_off.LEAF)
    exportHTML(r_on.NODES, r_on.LEAF, cfg, [], ...
               r_off.NODES, r_off.LEAF, r_on.elapsed, r_off.elapsed);
else
    fprintf('(Skipping HTML export — no complete leaves)\n');
end

% ===================== Interactive tree explorer =============================
cfg.useWeakRule = true;
plotInteractiveTree(r_on.NODES, r_on.LEAF, cfg, r_on.elapsed);
cfg.useWeakRule = false;
plotInteractiveTree(r_off.NODES, r_off.LEAF, cfg, r_off.elapsed);
